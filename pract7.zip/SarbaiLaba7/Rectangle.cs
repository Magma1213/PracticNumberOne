﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Media;

namespace SarbaiLaba7
{
    public class Rectangle : Figure
    {
        public Rectangle(int x, int y, int w, int h)
        {
            this.x = x; this.y = y; this.w = w; this.h = h;
        }

        public override void Draw(DrawingContext drawingContext)
        {
            var rect = new Rect(x, y, w, h);
            drawingContext.DrawRectangle(null, Init.Pen, rect);
        }

        public override void MoveTo(int deltax, int deltay)
        {
            if (x + deltax >= 0 && y + deltay >= 0 &&
                x + deltax + w <= Init.DrawingImage.ActualWidth &&
                y + deltay + h <= Init.DrawingImage.ActualHeight)
            {
                x += deltax;
                y += deltay;
            }
        }

        public void ChangeDimensions(int newW, int newH)
        {
            w = newW; h = newH;
        }
    }

    public class Square : Rectangle
    {
        public Square(int x, int y, int size) : base(x, y, size, size) { }
    }
}