﻿using System.Windows;
using System.Windows.Media;

namespace SarbaiLaba7
{
    public class Ellipse : Figure
    {
        public Ellipse(int x, int y, int w, int h)
        {
            this.x = x; this.y = y; this.w = w; this.h = h;
        }

        public override void Draw(DrawingContext drawingContext)
        {
            Point center = new Point(x + w / 2, y + h / 2);
            drawingContext.DrawEllipse(null, Init.Pen, center, w / 2, h / 2);
        }

        public override void MoveTo(int deltax, int deltay)
        {
            if (x + deltax >= 0 && y + deltay >= 0 &&
                x + deltax + w <= Init.DrawingImage.ActualWidth &&
                y + deltay + h <= Init.DrawingImage.ActualHeight)
            {
                x += deltax;
                y += deltay;
            }
        }
    }

    public class Circle : Ellipse
    {
        public Circle(int x, int y, int diameter) : base(x, y, diameter, diameter) { }

        public void ChangeRadius(int newRadius)
        {
            w = newRadius * 2;
            h = newRadius * 2;
        }
    }
}