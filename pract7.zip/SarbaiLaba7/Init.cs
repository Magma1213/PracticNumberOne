﻿using System.Windows.Controls;
using System.Windows.Media;

namespace SarbaiLaba7
{
    public static class Init
    {
        public static Pen Pen = new Pen(Brushes.Black, 2);
        public static Image DrawingImage { get; set; }
    }
}