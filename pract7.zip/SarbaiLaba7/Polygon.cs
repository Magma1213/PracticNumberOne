﻿using System.Windows;
using System.Windows.Media;

namespace SarbaiLaba7
{
    public class Polygon : Figure
    {
        public Point[] Points;

        public Polygon(Point[] points)
        {
            Points = points;
            if (points.Length > 0) { x = (int)points[0].X; y = (int)points[0].Y; }
        }

        public override void Draw(DrawingContext drawingContext)
        {
            StreamGeometry g = new StreamGeometry();
            using (var ctx = g.Open())
            {
                if (Points.Length > 0)
                {
                    ctx.BeginFigure(Points[0], true, true);
                    ctx.PolyLineTo(Points, true, false);
                }
            }
            drawingContext.DrawGeometry(null, Init.Pen, g);
        }

        public override void MoveTo(int deltax, int deltay)
        {
            for (int i = 0; i < Points.Length; i++)
            {
                Points[i].X += deltax;
                Points[i].Y += deltay;
            }
        }
    }

    public class Triangle : Polygon
    {
        public Triangle(Point p1, Point p2, Point p3) : base(new Point[] { p1, p2, p3 }) { }
    }
}