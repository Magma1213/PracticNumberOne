﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace SarbaiLaba7
{
    public abstract class Figure
    {
        public int x;
        public int y;
        public int w;
        public int h;

        public abstract void Draw(DrawingContext drawingContext);
        public abstract void MoveTo(int deltax, int deltay);
    }
}
