﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SarbaiLaba7
{
    public class ShapeContainer
    {
        public static List<Figure> FigureList = new List<Figure>();

        public static void AddFigure(Figure figure)
        {
            FigureList.Add(figure);
        }
    }
}