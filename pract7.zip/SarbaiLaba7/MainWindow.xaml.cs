﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace SarbaiLaba7
{
    public partial class MainWindow : Window
    {
        private RenderTargetBitmap? _renderTarget;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Init.DrawingImage = DrawingImage;

            int width = (int)DrawingImage.ActualWidth;
            int height = (int)DrawingImage.ActualHeight;
            if (width <= 0) width = 800;
            if (height <= 0) height = 600;

            _renderTarget = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            DrawingImage.Source = _renderTarget;
        }

        private void Redraw()
        {
            DrawingVisual drawingVisual = new DrawingVisual();
            using (var dc = drawingVisual.RenderOpen())
            {
                foreach (var figure in ShapeContainer.FigureList)
                {
                    figure.Draw(dc);
                }
            }
            _renderTarget?.Clear();
            if (_renderTarget != null)
            {
                _renderTarget.Render(drawingVisual);
                DrawingImage.Source = _renderTarget;
            }
        }

        private void BtnDraw_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int x = int.Parse(txtX.Text);
                int y = int.Parse(txtY.Text);
                int w = int.Parse(txtW.Text);
                int h = int.Parse(txtH.Text);

                Figure? newFigure = null;

                switch (cmbFigureType.SelectedIndex)
                {
                    case 0:
                        newFigure = new ComplexFace(x, y);
                        break;
                    case 1:
                        newFigure = new Rectangle(x, y, w, h);
                        break;
                    case 2:
                        newFigure = new Square(x, y, w);
                        break;
                    case 3:
                        newFigure = new Ellipse(x, y, w, h);
                        break;
                    case 4:
                        newFigure = new Circle(x, y, w);
                        break;
                    case 5:
                        newFigure = new Triangle(new Point(x, y), new Point(x + w, y), new Point(x + w / 2, y - h));
                        break;
                }

                if (newFigure != null)
                {
                    ShapeContainer.AddFigure(newFigure);
                    Redraw();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Некорректный формат числа!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnMove_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int dx = int.Parse(txtDX.Text);
                int dy = int.Parse(txtDY.Text);

                foreach (var figure in ShapeContainer.FigureList)
                {
                    figure.MoveTo(dx, dy);
                }

                Redraw();
            }
            catch (FormatException)
            {
                MessageBox.Show("Некорректный формат числа для смещения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ShapeContainer.FigureList.Clear();
            Redraw();
        }
    }
}