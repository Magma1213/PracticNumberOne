﻿using System.Windows;
using System.Windows.Media;

namespace SarbaiLaba7
{
    public class ComplexFace : Figure
    {
        public Rectangle face;
        public Circle leftEar;
        public Circle rightEar;
        public Triangle leftEye;
        public Triangle rightEye;
        public Triangle nose;

        public ComplexFace(int x, int y)
        {
            this.x = x;
            this.y = y;
            this.w = 200;
            this.h = 100;

            UpdateParts();
        }

 
        private void UpdateParts()
        {
            face = new Rectangle(x, y, 200, 100);
            leftEar = new Circle(x - 25, y - 25, 50);
            rightEar = new Circle(x + 175, y - 25, 50);

            leftEye = new Triangle(new Point(x + 40, y + 50), new Point(x + 60, y + 50), new Point(x + 50, y + 20));
            rightEye = new Triangle(new Point(x + 140, y + 50), new Point(x + 160, y + 50), new Point(x + 150, y + 20));
            nose = new Triangle(new Point(x + 80, y + 80), new Point(x + 120, y + 80), new Point(x + 100, y + 60));
        }

        public override void Draw(DrawingContext drawingContext)
        {
            face.Draw(drawingContext);
            leftEar.Draw(drawingContext);
            rightEar.Draw(drawingContext);
            leftEye.Draw(drawingContext);
            rightEye.Draw(drawingContext);
            nose.Draw(drawingContext);
        }

        public override void MoveTo(int dx, int dy)
        {

            if (x - 25 + dx >= 0 &&
                y - 25 + dy >= 0 &&
                x + 225 + dx <= Init.DrawingImage.ActualWidth &&
                y + 100 + dy <= Init.DrawingImage.ActualHeight)
            {

                x += dx;
                y += dy;


                UpdateParts();
            }
        }
    }
}